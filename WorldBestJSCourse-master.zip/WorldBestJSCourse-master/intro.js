console.log("I am an external JS File");
